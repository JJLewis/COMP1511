#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {

    printf("argc is %d\n", argc);
    int i = 0;
    while (i < argc) {
        printf("argv[%d] is %s\n", i, argv[i]);
        i++;
    }
    int x = atoi(argv[1]);
    int y = atoi(argv[2]);
    int z = atoi(argv[3]);

    printf("Sum of the first 3 arguments is %d.\n", x+y+z);

    return 0;
}
