#include <stdio.h>

int main(void) {

    int numDigits = 0;
    int sum = 0;

    char ch = getchar();
    while(ch != EOF) {
        if (ch >= '0' && ch <= '9') {
            //printf("-> %c <-\n", ch);
            numDigits++;
            sum += (ch - '0');
        }
        ch = getchar();
    }
    printf("Input contained %d digits which summed to %d\n", numDigits, sum);
    return 0;
}
