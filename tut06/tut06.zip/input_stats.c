#include <stdio.h>

int main(void) {

    int numBlanks = 0;
    int lengthCurrentWord = 0;
    int lengthShortestWord = 10000000, lengthLongestWord = 0;
    int numWords = 0;

    char ch = getchar();
    while(ch != EOF) {
        if (ch == ' ' || ch == '\t' || ch == '\n') {
            numBlanks++;
            if (lengthCurrentWord > 0) {
                if (lengthCurrentWord > lengthLongestWord) {
                    lengthLongestWord = lengthCurrentWord;
                }
                if (lengthCurrentWord < lengthShortestWord) {
                    lengthShortestWord = lengthCurrentWord;
                }
                numWords++;
            }
            lengthCurrentWord = 0;
        } else {
            lengthCurrentWord++;
        }

        ch = getchar();
    }
    printf("Input contained %d blanks, tabs or new lines.\n", numBlanks);
    printf("Number of words: %d\n", numWords);
    printf("Length of longest word: %d\n", lengthLongestWord);
    printf("Length of shortest word: %d\n", lengthShortestWord);
    return 0;
}
